<html>
<title>Daktari -Login</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'/>
<link href='css/login.css' rel='stylesheet' type='text/css'/>
<style>
a:focus {
outline: none;
}
</style>
<body class="login">
<div id="logo-bar">
<img src="images/Logo.png" style="height:39px"/>
</div>
<div id="login-form">
<br/>

<div class="login-header">
</div>
<div class="login-left">
<img src="images/register.png"/>
</div>
<div class="login-right">
<span class="intro">You can Register / Sign In for any of the following.</span>

<div class="login-item">
<a href="googleprocess.php?type=patient"><img src="images/patient.png"/></a>
<div class="text">
<a href="googleprocess.php?type=patient"><h5>Patient</h5></a>
<span>Connect to doctors ,Request Appointments and  Prescriptions from doctors, Get Notifications of hospital Events   </span>
</div>
<div style="clear:both"></div>
</div>

<div class="login-item">
<a href="googleprocess.php?type=doctor"><img src="images/doctor.png"/></a>
<div class="text">
<a href="googleprocess.php?type=doctor"><h5>Doctor</h5></a>
<span>Connect to patients, Manage Appointments , Send Prescriptions and get Notifications of hospital Events  </span>
</div>
<div style="clear:both"></div>
</div>

<div class="login-item" style="border-bottom:none">
<a href="googleprocess.php?type=hospital"><img src="images/hospital.png"/></a>
<div class="text">
<a href="googleprocess.php?type=hospital"><h5>Hospital</h5></a>
<span>This lets you create hospitals manage hospital events confirm doctors </span>
</div>
<div style="clear:both"></div>
</div>
</div>
<div style="clear:both"></div>
</div>
</body>
</html>