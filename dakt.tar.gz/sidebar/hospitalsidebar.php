		<div id="navigation-block">
            <ul id="sliding-navigation" class="nav nav-list">
				<li class="sliding-element nav-header"><a href="#" >Home</a></li>
      <li class="sliding-element nav-header"><a href="#" id="notifications_display_id" >Notifications</a> <span class="badge badge-important" id="notifications_display">0</span></li>
	  
            </ul>
        </div>
