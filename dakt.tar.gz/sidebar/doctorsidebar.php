		<div id="navigation-block">
            <ul id="sliding-navigation" class="nav nav-list">
				<li class="sliding-element nav-header"><a href="">Home</a></li>
                <li class="sliding-element nav-header"><a href="#" id="notifications_display_id" >Notifications</a> <span class="badge badge-important" id="notifications_display">0</span></li>
				<li class="sliding-element nav-header showmenu"><img src="images/download.png"><a href="#appointment">Appointments</a></li>
					<ul class="nav nav-list" id="appointment" style="display:none;">
						<li class="sliding-element side-nav" id="doc-appointment" ><a href="#" style="margin-left:20px">Upcoming</a></li>
						<li class="sliding-element side-nav" id="doc-request"><a href="#" style="margin-left:20px">Requests</a></li>
					</ul>
             <!--   <li class="sliding-element nav-header showmenu"><img src="images/download.png"><a href="#doctormenu">Patients</li>
					<ul class="nav nav-list" id="doctormenu" style="display:none;">
						<li class="sliding-element"><a href="#" style="margin-left:20px">View</a></li>
					</ul>-->
					<li class="sliding-element nav-header showmenu" ><img src="images/download.png"><a href="#prescriptionmenu">Prescription</a></li>
					<ul class="sliding-element nav nav-list" id="prescriptionmenu" style="display:none;">
						<li class="sliding-element"><a href="#" style="margin-left:20px" class="list_myprescription_sent" >Sent</a></li>
						<li class="sliding-element"><a href="#" style="margin-left:20px" class="list_myprescription_saved">Saved Presciptions</a></li>
					</ul>
						<li class="sliding-element nav-header showmenu" ><img src="images/download.png"><a href="#hospitalmenu">Hospital</a></li>
					<ul class="sliding-element nav nav-list" id="hospitalmenu" style="display:none;">
						
						<li class="sliding-element"><a href="#" style="margin-left:20px" class="view_hospitals">Add Hospital</a></li>
					</ul>
            </ul>
        </div>