              <div class="  btn-group">
                    <button class="btn navig">
						<div class="nav-info active" id="hosp-doctor">
								<div class="row">
									<div class="span1 nav-image">
										<img src="images/doctor_info-icon.gif" style="width:49px;"/>
									</div>
									<div class="span2 nav-details">
										<h3 id="doc_no"><?php echo $doctors;?></h3>
										<p>Doctors</p>
									</div>
								</div>
						</div>
                    </button>
					<button class="btn navig">
                        <div class="nav-info" id="hosp-patient">
							<div class="span4">
								<div class="row">
									<div class="span1 nav-image">
										<img src="images/doctor_info-icon.gif" style="width:49px;"/>
									</div>
									<div class="span2 nav-details">
										<h3 id="pat_no"><?php echo $patients;?></h3>
										<p>Patients</p>
									</div>
								</div>
							</div>
						</div>
                    </button>
					<button class="btn navig">
                        <div class="nav-info" id="hosp-requests">
							<div class="span4">
								<div class="row">
									<div class="span1 nav-image">
										<img src="images/doctor_info-icon.gif" style="width:49px;"/>
									</div>
									<div class="span2 nav-details">
										<h3 id="req_no"><?php echo $requests;?></h3>
										<p>Requests</p>
									</div>
								</div>
							</div>
						</div>
                    </button>
				</div>
  


	

    