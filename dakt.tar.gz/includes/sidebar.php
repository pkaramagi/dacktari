					<div class="span3 nav-container">					
							<ul class="nav nav-list" id="side-menu">
								<li>Home</li>
								<li>Notifications</li>
								<li>Appointments
																	</li>
								<li >Doctors
									
								</li>
								<li >Prescriptions
									
								</li>
								
							</ul>
						
					</div>