             <link href="css/navigate.css" type="text/css" rel="stylesheet"/> 
              <div class="  btn-group">
                    <button class="btn">
						<div class="nav-info active">
								<div class="row">
									<div class="span1 nav-image">
										<img src="images/doctor_info-icon.gif" style="width:49px;"/>
									</div>
									<div class="span2 nav-details">
										<h3>14</h3>
										<p>UpComing Appointments</p>
									</div>
								</div>
						</div>
                    </button>
					<button class="btn">
                        <div class="nav-info">
							<div class="span4">
								<div class="row">
									<div class="span1 nav-image">
										<img src="images/doctor_info-icon.gif" style="width:49px;"/>
									</div>
									<div class="span2 nav-details">
										<h3>10</h3>
										<p>Pending Appointments</p>
									</div>
								</div>
							</div>
						</div>
                    </button>
					<button class="btn">
                        <div class="nav-info">
							<div class="span4">
								<div class="row">
									<div class="span1 nav-image">
										<img src="images/doctor_info-icon.gif" style="width:49px;"/>
									</div>
									<div class="span2 nav-details">
										<h3>09</h3>
										<p>Cancelled</p>
									</div>
								</div>
						</div>
						</div>
                    </button>
					
                </div>
        